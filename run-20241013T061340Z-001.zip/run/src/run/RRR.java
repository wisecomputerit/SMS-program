package run;

import java.awt.Robot;
import java.awt.AWTException;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JFrame;
import javax.swing.JLabel;


public class RRR {



public static void main (String[] args) throws AWTException, InterruptedException {
	/*
       URL_system();

	mouse_system(4000); // 
	
	text_system(600,350); //
	
	*/
	TextComponentFrame   Frame  =new TextComponentFrame();
	Frame.main(args);
      /*
	  Thread.sleep(4000);
	text_system(600,250); // 

	
	String [] phone = read_data(); // 讀取資料庫
	phone(phone);
	
	  Thread.sleep(500);
	text_system(1800,250); 
	
	*/
}
public static void phone(String [] phone_name) throws AWTException, InterruptedException {


	int len;
	String name;


	for(int i=0;i<phone_name.length;i++)
	{
		
		/*
		System.out.println("            "+phone_name[i].substring(0,1));
		System.out.println("            "+phone_name[i].substring(1,2));
		System.out.println("            "+phone_name[i].substring(2,3));
		System.out.println("            "+phone_name[i].substring(3,4));
		System.out.println("            "+phone_name[i].substring(4,5));
		System.out.println("            "+phone_name[i].substring(5,6));
		System.out.println("            "+phone_name[i].substring(6,7));
		System.out.println("            "+phone_name[i].substring(7,8));
		System.out.println("            "+phone_name[i].substring(8,9));
		System.out.println("            "+phone_name[i].substring(9,10));
        

		int num1 = Integer.parseInt(phone_name[i].substring(0,1));
		int num2 = Integer.parseInt(phone_name[i].substring(1,2));
		int num3 = Integer.parseInt(phone_name[i].substring(2,3));
		int num4 = Integer.parseInt(phone_name[i].substring(3,4));
	
		int num5 = Integer.parseInt(phone_name[i].substring(4,5));
		int num6 = Integer.parseInt(phone_name[i].substring(5,6));
		int num7 = Integer.parseInt(phone_name[i].substring(6,7));
		int num8 = Integer.parseInt(phone_name[i].substring(7,8));
		int num9 = Integer.parseInt(phone_name[i].substring(8,9));
		int num10 = Integer.parseInt(phone_name[i].substring(9,10));
		  
		Thread.sleep(500);
		nullA(num1);
	    Thread.sleep(500);
		nullA(num2);
	    Thread.sleep(500);
		nullA(num3);
	    Thread.sleep(500);
		nullA(num4);
	    Thread.sleep(500);
		nullA(num5);
	    Thread.sleep(500);
		nullA(num6);
	    Thread.sleep(500);
		nullA(num7);
	    Thread.sleep(500);
		nullA(num8);
	    Thread.sleep(500);
		nullA(num9);
	    Thread.sleep(500);
		nullA(num10);
	    Thread.sleep(2000);
		nullpas();
	    Thread.sleep(2000);
	    */
		name=phone_name[i];
	
		System.out.println("len "+name.length());
		char []  Anull = new char[name.length()];
		for(int j=0;j<name.length();j++)
		{
			
			  Anull[i]=name.charAt(j);
			  
			
				String num=Character.toString(Anull[i]);
				  System.out.print("Anull =" +  Anull[i]+" j ="+j+"num ="+num+"\n");
			  nullA(num);
			
		}
		nullpas();
		
		
		
		
	}


}

public static void    nullpas() throws AWTException
{
	
	 Robot robot = new Robot();
	   robot.keyPress(KeyEvent.VK_ENTER);
}




public static void    nullA(String num) throws AWTException, InterruptedException
{
	int  time =500;
	   Thread.sleep(200);
		if(num.equals("+"))
		{  Robot robot = new Robot();
		
		    robot.keyPress(KeyEvent.VK_ADD);
			System.out.println(" 	VK_ADD");
			   Thread.sleep(time);
		}
	if(num.equals(" "))
	{  Robot robot = new Robot();
	
	    robot.keyPress(KeyEvent.VK_SPACE);
		System.out.println("VK_SPACE");
		   Thread.sleep(time);
	}
	
	if(num.equals("0"))
	{  Robot robot = new Robot();
	
	    robot.keyPress(KeyEvent.VK_0);
		System.out.println(" VK_0");
		   Thread.sleep(time);
	}
	if(num.equals("1"))
	{  Robot robot = new Robot();
	
	    robot.keyPress(KeyEvent.VK_1);
		System.out.println(" VK_1");
		   Thread.sleep(time);
	}
	if(num.equals("2"))
	{  Robot robot = new Robot();
	
	    robot.keyPress(KeyEvent.VK_2);
		System.out.println("VK_2");
		   Thread.sleep(time);
	}
	if(num.equals("3"))
	{  Robot robot = new Robot();
	
	    robot.keyPress(KeyEvent.VK_3);
		System.out.println(" VK_3");
		   Thread.sleep(time);
	}
	if(num.equals("4"))
	{  Robot robot = new Robot();
	
	    robot.keyPress(KeyEvent.VK_4);
		System.out.println(" VK_4");
		   Thread.sleep(time);
	}
	if(num.equals("5"))
	{  Robot robot = new Robot();
	
	    robot.keyPress(KeyEvent.VK_5);
		System.out.println(" VK_5");
		   Thread.sleep(time);
	}
	if(num.equals("6"))
	{  Robot robot = new Robot();
	
	    robot.keyPress(KeyEvent.VK_6);
		System.out.println(" VK_6");
		   Thread.sleep(time);
	}
	if(num.equals("7"))
	{  Robot robot = new Robot();
	
	    robot.keyPress(KeyEvent.VK_7);
		System.out.println(" VK_7");
		   Thread.sleep(time);
	}
	if(num.equals("8"))
	{  Robot robot = new Robot();
	
	    robot.keyPress(KeyEvent.VK_8);
		System.out.println(" VK_8");
		   Thread.sleep(time);
	}
	if(num.equals("9"))
	{  Robot robot = new Robot();
	
	    robot.keyPress(KeyEvent.VK_9);
		System.out.println(" VK_9");
		   Thread.sleep(time);
	}

}


public static String [] read_data()
{
	List <String> weekDays = new ArrayList<>();
	
	
	int i =0;
	 String filePath = "example.txt";
    try (FileReader fileReader = new FileReader(filePath);
            BufferedReader bufferedReader = new BufferedReader(fileReader)) {
           String line;
           while ((line = bufferedReader.readLine()) != null) {
        	     i++;
               System.out.println(line+" i="+i);
         //      name[i]=line;
               
               weekDays.add(line);
          
           }
       } catch (IOException e) {
           System.out.println("Error reading file: " + e.getMessage());
       }
    
	
	String [] name  = new String [weekDays.size()];
	
	
	for (i = 0; i < weekDays.size(); i++) {
		
		
	    System.out.println(weekDays.get(i));
	    name[i]=weekDays.get(i);
	    
	    
	}
	return name;
}


public static  void readdata()
{

	
	int i =0;
	 String filePath = "example.txt";
	 String filePath_OK = "example_OK.txt";
	 
    try (FileReader fileReader = new FileReader(filePath);
            BufferedReader bufferedReader = new BufferedReader(fileReader)) {
    	
    	String firstLine =bufferedReader.readLine();
    	
    	FileWriter f = new FileWriter(filePath_OK);
    	BufferedWriter B = new BufferedWriter(f );
    	
           String line;
           while ((line = bufferedReader.readLine()) != null) {
        
               
               B.write(line+"\n");
          
           }
           bufferedReader.close();
           B.close();
           fileReader.close();
           f.close();
           
           File file = new  File(filePath);
           file.delete();
           
           File tempFile = new File(filePath_OK);
           tempFile.renameTo(file);
           
       } catch (IOException e) {
           System.out.println("Error reading file: " + e.getMessage());
       }
    
	


}










public static void URL_system()
{
	

	try {
		String url = "https://messages.google.com/web/conversations";
		java.net.URI uri = java.net.URI.create(url);
		// 獲取當前系統桌面擴充套件
		java.awt.Desktop dp = java.awt.Desktop.getDesktop();
		// 判斷系統桌面是否支援要執行的功能
		if (dp.isSupported(java.awt.Desktop.Action.BROWSE)) {
			dp.browse(uri);
			// 獲取系統預設瀏覽器開啟連結
		}
	} catch (java.lang.NullPointerException e) {
		// 此為uri為空時丟擲異常
		e.printStackTrace();
	} catch (java.io.IOException e) {
		// 此為無法獲取系統預設瀏覽器
		e.printStackTrace();
	}


}

public static void mouse_system(int time) throws InterruptedException
{
try {
		
		
    Thread.sleep(time);
		Robot robot = new Robot();


		robot.mouseMove(150,240); // 模拟鼠标移动到坐标(100, 100)处
		robot.mousePress(InputEvent.BUTTON1_DOWN_MASK); // 模拟按下鼠标左键
		robot.mouseRelease(InputEvent.BUTTON1_DOWN_MASK); // 模拟释放鼠标左键
		/*
		robot.keyPress(KeyEvent.VK_ENTER); // 模拟按下回车键
		robot.keyRelease(KeyEvent.VK_ENTER); // 模拟释放回车键
VK_SPACE
		*/



		} catch (AWTException e) {
		e.printStackTrace();
		}



}


public static void text_system(int w,int h)
{
	
	try {
		
		
		
		Robot robot = new Robot();


		robot.mouseMove(w, h); // 模拟鼠标移动到坐标(100, 100)处
		robot.mousePress(InputEvent.BUTTON1_DOWN_MASK); // 模拟按下鼠标左键
		robot.mouseRelease(InputEvent.BUTTON1_DOWN_MASK); // 模拟释放鼠标左键
		/*
		robot.keyPress(KeyEvent.VK_ENTER); // 模拟按下回车键
		robot.keyRelease(KeyEvent.VK_ENTER); // 模拟释放回车键

		*/



		} catch (AWTException e) {
		e.printStackTrace();
		}



}








}









